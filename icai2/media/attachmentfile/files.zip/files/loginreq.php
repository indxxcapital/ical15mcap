<?php 
require 'include/core.php';

save_user_log();

$return_array=array();


if($_REQUEST['username']=='')
{
$return_array['status']=false;
$return_array['description']="Empty Request";
}
else{
$user=getSingleUserbyName($_REQUEST['username']);
//print_r($user);
if(!empty($user))
{	

	if($user['status']==0)
	{
$return_array['status']=false;
$return_array['description']="Inactive User!";
	}
	else{
	
	$flag=getActiveUser($_REQUEST['username']);
	if($flag)
	{
	$return_array['status']=true;
$return_array['description']="Logged In Suggessfully!";
saveUserLoginReq();

	}else{
	$return_array['status']=false;
$return_array['description']="Already Logged In!";
	}
	
	}
	








}else{
$return_array['status']=false;
$return_array['description']="No Such User Exist!";
}



}




save_user_log_responce(json_encode($return_array));
echo json_encode($return_array);

?>