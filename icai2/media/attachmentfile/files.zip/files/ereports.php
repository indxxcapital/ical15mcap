<?php


require 'libs/Smarty.class.php';
require 'include/core.php';

$smarty = new Smarty;

if(!$_SESSION['username'])
{	header('Location: index.php');
}
//print_r($_SESSION);
//exit;


//print_r($_POST);

if(!empty($_POST) && $_POST['date'])
{
	
	
$query=mysql_query("Select IF(status = '1','Active','Inactive')  as status,name,userid,van,noofentitelments,companyname,activationdate,deactivationdate,typeofnetwork,address from tbl_user_entitlementreport where sysdate like '".date("Y-m-d",strtotime($_POST['date']))."%'");
$earray=array();

if(mysql_num_rows($query)>0)
{
while($row=mysql_fetch_assoc($query))
{
$earray[]=$row;
}
if($_POST['typeofexport']=='csv')
{
 header("Content-Type:  application/csv"); 
  header('Content-Disposition: attachement; filename="ereports'.$_POST['date'].'.csv";');
 $flag = false; foreach($earray as $row) { if(!$flag) {
	  // display field/column names as first row 
	  echo implode(";", array_keys($row)) . "\r\n";
	   $flag = true;
	    } echo implode(";", array_values($row)) . "\r\n"; 
		}
		 exit;
	
	}
else{


 header("Content-Type: text/plain"); 
  header('Content-Disposition: attachement; filename="ereports'.$_POST['date'].'.txt";');
 $flag = false; foreach($earray as $row) { if(!$flag) {
	  // display field/column names as first row 
	  echo implode("\t", array_keys($row)) . "\r\n";
	   $flag = true;
	    } echo implode("\t", array_values($row)) . "\r\n"; 
		}
		 exit;


}
}else{
$smarty->assign("error",1);
}

}
save_audit_trial("Entitlement Report");
$typeofdata=array("txt"=>"Text","csv"=> "CSV");

$smarty->assign("typeofdata",$typeofdata);

$array =setHead();
$smarty->assign("metas",$array);
$smarty->display('home/ereports.tpl');
