<?php
 /**
 * Example Application

 * @package Example-application
 */





require 'libs/Smarty.class.php';
require 'include/core.php';

$smarty = new Smarty;

if(!$_SESSION['username'])
{	header('Location: index.php');
}
//print_r($_SESSION);
//exit;

if(!empty($_POST))
{
//	print_r($_POST);
//exit;
	
	$query=mysql_query("Select * from tbl_client where userid='".mysql_real_escape_string($_POST['userid'])."'");
	if(mysql_num_rows($query)>0)
	{
		$smarty->assign("error",1);
	}
	else{
		if($_POST['status'])
		$subQuery=" status='".mysql_real_escape_string($_POST['status'])."',
		activationdate='".mysql_real_escape_string(date("Y-m-d H:i:s"))."',
	 ";
		
	mysql_query("insert into tbl_client set ".$subQuery."
	 name='".mysql_real_escape_string($_POST['name'])."',
	 username='".mysql_real_escape_string($_POST['user_name'])."',
	 userid='".mysql_real_escape_string($_POST['userid'])."',
	 van='".mysql_real_escape_string($_POST['van'])."',
	 noofentitelments='".mysql_real_escape_string($_POST['noentitlements'])."',
	 companyname='".mysql_real_escape_string($_POST['company'])."',
	 typeofnetwork='".mysql_real_escape_string(implode(",",$_POST['networktype']))."',
	 address='".mysql_real_escape_string($_POST['address'])."';
	  ");
	  	$smarty->assign("success",1);
	}
	
/*$email =$_POST['sender_email'] ;
$sub = 'New Registration on GLCEM';
$message='First Name : '.mysql_real_escape_string($_POST['sender_name']).'<br>Last Name : '.mysql_real_escape_string($_POST['sender_lname']).'<br>Email : '.mysql_real_escape_string($_POST['sender_email']).'<br>Phone : '.mysql_real_escape_string($_POST['phone']).'<br>Address : '.mysql_real_escape_string($_POST['address']).'<br>City : '.mysql_real_escape_string($_POST['city']).'<br>
Pincode : '.mysql_real_escape_string($_POST['pincode']).'<br>Country : '.mysql_real_escape_string($_POST['country']).'<br>
User Type : '.mysql_real_escape_string($_POST['utype']).'<br>';	$headers = "From: ". strip_tags($email) . "\r\n";
		$headers = "From: ". strip_tags($email) . "\r\n";
			$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
			 mail("dbajpai@indxx.com",$sub,$message,$headers);*/
		
	
save_audit_trial("Add User", $_POST['name']);
		//	header('Location: addnew.php');
	
	
	//mysql_real
	
	
}



$typeofdata=array("OpenBook"=>"OpenBook","Network A"=> "Network A","Network B"=>"Network B");

$smarty->assign("typeofdata",$typeofdata);
//save_audit_trial();
//$smarty->force_compile = true;
$smarty->debugging = false;
$smarty->caching = false;
$smarty->cache_lifetime = 120;

$array =setHead();
$smarty->assign("metas",$array);

$smarty->display('home/addnew.tpl');
