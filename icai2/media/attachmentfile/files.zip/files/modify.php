<?php
 /**
 * Example Application

 * @package Example-application
 */





require 'libs/Smarty.class.php';
require 'include/core.php';






$smarty = new Smarty;


$myoptions=getUserList();
$smarty->assign("myOptions",$myoptions);
$smarty->assign("status",array("1"=>"Active","0"=>"Inactive"));
	
	
	
	
if(!$_SESSION['username'])
{	header('Location: index.php');
}
//print_r($_SESSION);
//exit;


if(!empty($_POST) && $_POST['wt_update'])
{
//	print_r($_POST);
//exit;


//echo "do something";

mysql_query("update tbl_client set status='".mysql_real_escape_string($_POST['status'])."',
	 name='".mysql_real_escape_string($_POST['name'])."',
	 username='".mysql_real_escape_string($_POST['user_name'])."',
	 van='".mysql_real_escape_string($_POST['van'])."',
	 noofentitelments='".mysql_real_escape_string($_POST['noentitlements'])."',
	 companyname='".mysql_real_escape_string($_POST['company'])."',
	 activationdate='".mysql_real_escape_string(date("Y-m-d",strtotime($_POST['activation_date'])))."',
	 deactivationdate='".mysql_real_escape_string(date("Y-m-d",strtotime($_POST['deactivation_date'])))."',
	 typeofnetwork='".mysql_real_escape_string(implode(",",$_POST['networktype']))."',
	 address='".mysql_real_escape_string($_POST['address'])."' where id='".$_GET['userid']."';
	  ");
	
$smarty->assign("success",1);

	save_audit_trial("Modify User",$_POST['name']);
	
	
	

	
}
$user=array();
if($_GET['userid'])
{
		$smarty->assign("displayform",1);
		
		$user=getSingleUser($_GET['userid']);
	//print_r($user);	
		
		$selectedUserData=explode(",",$user['typeofnetwork']);
		$smarty->assign("selectedUserData",$selectedUserData);
		
		$smarty->assign("userdata",$user);
		$smarty->assign("mySelect",$user['id']);
		$smarty->assign("mystatus",$user['status']);
		save_audit_trial("Modify User", $user['userid']);
}else{
			$smarty->assign("displayform",0);
			save_audit_trial("Modify User");
}

$typeofdata=array("OpenBook"=>"OpenBook","Network A"=> "Network A","Network B"=>"Network B");

$smarty->assign("typeofdata",$typeofdata);

//$smarty->force_compile = true;
$smarty->debugging = false;
$smarty->caching = false;
$smarty->cache_lifetime = 120;

$array =setHead();
$smarty->assign("metas",$array);

$smarty->display('home/modify.tpl');
