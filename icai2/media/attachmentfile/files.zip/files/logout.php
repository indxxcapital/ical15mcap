<?php 


require 'libs/Smarty.class.php';
require 'include/core.php';
save_audit_trial("Logout",$_SESSION['username']);	
unset($_SESSION['username']);
	

unset($_SESSION);
header('Location: index.php');

?>