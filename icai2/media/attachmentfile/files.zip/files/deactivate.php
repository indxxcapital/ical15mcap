<?php
 /**
 * Example Application

 * @package Example-application
 */





require 'libs/Smarty.class.php';
require 'include/core.php';






$smarty = new Smarty;


$myoptions=getUserList(1);
$smarty->assign("myOptions",$myoptions);
$smarty->assign("status",array("1"=>"Active","0"=>"Inactive"));
	
	
	
	
if(!$_SESSION['username'])
{	header('Location: index.php');
}
//print_r($_SESSION);
//exit;


if(!empty($_POST) && $_POST['wt_update'])
{
//	print_r($_POST);
//exit;


//echo "do something";

mysql_query("update tbl_client set status='0' ,deactivationdate='".date("Y-m-d H:i:s")."'
where id ='".$_GET['userid']."' ");
$smarty->assign("success",1);
save_audit_trial();

	
	
	
	

	
}
$user=array();
if($_GET['userid'])
{
		$smarty->assign("displayform",1);
		
		$user=getSingleUser($_GET['userid']);
	//print_r($user);	
		
		$smarty->assign("userdata",$user);
		$smarty->assign("mySelect",$user['id']);
		$smarty->assign("mystatus",$user['status']);
		save_audit_trial("Deactivate User", $user['userid']);
}else{
			$smarty->assign("displayform",0);
			save_audit_trial("Deactivate User");
}


//$smarty->force_compile = true;
$smarty->debugging = false;
$smarty->caching = false;
$smarty->cache_lifetime = 120;

$array =setHead();
$smarty->assign("metas",$array);

$smarty->display('home/deactivate.tpl');
