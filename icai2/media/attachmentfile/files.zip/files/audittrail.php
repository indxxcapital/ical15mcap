<?php
 /**
 * Example Application

 * @package Example-application
 */





require 'libs/Smarty.class.php';
require 'include/core.php';

$smarty = new Smarty;

if(!$_SESSION['username'])
{	header('Location: index.php');
}
//print_r($_SESSION);
//exit;

$txt=array();
$users=getAuditTrail();
if(!empty($users))
{
foreach($users as $client)
{

$txt[]="['".$client['sysdate']."','".$client['ipaddr']."','".$client['event']."','".$client['parameter']."']";
}

}
save_audit_trial("Audit Trail");

if(!empty($txt))
$str=implode(",",$txt);
$newstr='['.$str.'];';

$smarty->assign("users",$newstr);
//$smarty->force_compile = true;
$smarty->debugging = false;
$smarty->caching = false;
$smarty->cache_lifetime = 120;

$array =setHead();
$smarty->assign("metas",$array);

$smarty->display('home/audittrail.tpl');
