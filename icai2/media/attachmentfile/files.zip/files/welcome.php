<?php
 /**
 * Example Application

 * @package Example-application
 */





require 'libs/Smarty.class.php';
require 'include/core.php';

$smarty = new Smarty;

if(!$_SESSION['username'])
{	header('Location: index.php');
}

save_audit_trial("Welcome");


//$smarty->force_compile = true;
$smarty->debugging = false;
$smarty->caching = false;
$smarty->cache_lifetime = 120;

$array =setHead();
$smarty->assign("metas",$array);

$smarty->display('welcome.tpl');
