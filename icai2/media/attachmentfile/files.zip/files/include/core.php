<?php 
session_start();

include 'configs/dbconfig.php';

function save_audit_trial($page='', $param='')
{
	unset($_REQUEST['PHPSESSID']);
	
	
	//print_r($_SERVER);
//	echo "insert into  tbl_audit_trail (	ipaddr,event,useragent,parameter) values ('".$_SERVER['REMOTE_ADDR']."','".$_SERVER['REQUEST_URI']."','".$_SERVER['HTTP_USER_AGENT']."','".json_decode($_REQUEST)."');";
	if(!empty($_REQUEST))
mysql_query("insert into  tbl_audit_trail (	ipaddr,event,useragent,parameter) values ('".$_SERVER['REMOTE_ADDR']."','".$page."','".$_SERVER['HTTP_USER_AGENT']."','".$param."');");
else
mysql_query("insert into  tbl_audit_trail (	ipaddr,event,useragent) values ('".$_SERVER['REMOTE_ADDR']."','".$page."','".$_SERVER['HTTP_USER_AGENT']."');");


}
function save_user_log()
{

		if(!empty($_REQUEST))
mysql_query("insert into  tbl_user_log (	ipaddr,event,useragent,parameter,username) values ('".$_SERVER['REMOTE_ADDR']."','".$_SERVER['REQUEST_URI']."','".$_SERVER['HTTP_USER_AGENT']."','".str_replace(":"," : ",json_encode($_REQUEST))."','".$_REQUEST['username']."');");
else
mysql_query("insert into  tbl_user_log (ipaddr,event,useragent) values ('".$_SERVER['REMOTE_ADDR']."','".$_SERVER['REQUEST_URI']."','".$_SERVER['HTTP_USER_AGENT']."');");




}
function saveUserLoginReq(){
mysql_query("insert into  tbl_user_login (	ipaddr,loginstatus,username) values ('".$_SERVER['REMOTE_ADDR']."','1','".$_REQUEST['username']."');");
}
function save_user_log_responce($responce)
{

		if(!empty($responce))
mysql_query("insert into  tbl_user_log (	ipaddr,event,useragent,parameter,username) values ('".$_SERVER['REMOTE_ADDR']."','".$_SERVER['REQUEST_URI']."','".$_SERVER['HTTP_USER_AGENT']."','".str_replace(":"," : ",json_encode($responce))."','".$_REQUEST['username']."');");
else
mysql_query("insert into  tbl_user_log (ipaddr,event,useragent) values ('".$_SERVER['REMOTE_ADDR']."','".$_SERVER['REQUEST_URI']."','".$_SERVER['HTTP_USER_AGENT']."');");




}

function getResults($query)
{   
    $push = array();
    $result = mysql_query($query) or trigger_error(mysql_error());
   
   
    while($row = mysql_fetch_assoc($result))
    {
    	// I doubt you actually need to run stripslashes on your data...
    	$row = array_map('stripslashes', $row);
   
   
    	$push[] = $row;
    }

    return $push;
}

function getUseraudittrack($post){
$subQuery='';

//echo "select * from tbl_user_log where 1=1  ".$subQuery;


$query=mysql_query("select * from tbl_audit_trail where 1=1  order by sysdate desc");
$return_array=array();
if(mysql_num_rows($query)>0)
{
//$return_array['']
while($row=mysql_fetch_assoc($query))
{
$return_array[]=$row;
}

}

return $return_array;
}

function setHead()
{
	$filename=basename($_SERVER['PHP_SELF']);
	
	
	
$array=array();
	
	
	if($filename=="index.php")	
	{
		$array['title']="Clients Entitlements";
		$array['keyword']="Clients Entitlements";
		$array['desc']="Details about this company";	
	}
	if($filename=="modify.php")	
	{
		$array['title']="Modify | Clients Entitlements";
		$array['keyword']="Contact Us | Clients Entitlements";
		$array['desc']="Details about this company";	
	}if($filename=="ereports.php")	
	{
		$array['title']="Reports | Clients Entitlements";
		$array['keyword']="Contact Us | Clients Entitlements";
		$array['desc']="Details about this company";	
	}
	if($filename=="audittrail.php")	
	{
		$array['title']="Audit Trail Reports | Clients Entitlements";
		$array['keyword']="Contact Us | Clients Entitlements";
		$array['desc']="Details about this company";	
	}
	
	if($filename=="welcome.php")	
	{
		$array['title']="Welcome | Clients Entitlements";
		$array['keyword']="Contact Us | Clients Entitlements";
		$array['desc']="Details about this company";	
	}if($filename=="deactivate.php")	
	{
		$array['title']="Deactivate | Clients Entitlements";
		$array['keyword']="Sign up | Clients Entitlements";
		$array['desc']="Details about this company";	
	}if($filename=="userlist.php")	
	{
		$array['title']="List Clients | Clients Entitlements";
		$array['keyword']="List Clients  | Clients Entitlements";
		$array['desc']="Details about this company";	
	}if($filename=="addnew.php")	
	{
		$array['title']="Add new Clients | Clients Entitlements";
		$array['keyword']="Add new Clients  | Clients Entitlements";
		$array['desc']="Details about this company";	
	}
	

	
$array['sessdata']=$_SESSION;

	return $array;	
	
}

function getUserList($status=0){

if($status)
$subQuery= " and status ='1'";

$query=mysql_query("select * from tbl_client where 1=1 ".$subQuery."  order by userid asc");
$return_array=array();
if(mysql_num_rows($query)>0)
{
//$return_array['']
while($row=mysql_fetch_assoc($query))
{
$return_array[$row['id']]=$row['userid'];
}

}



return $return_array;
}

function getUserListByName(){

$query=mysql_query("select * from tbl_client order by userid asc");
$return_array=array();
$return_array[]="Select ";
if(mysql_num_rows($query)>0)
{
//$return_array['']
while($row=mysql_fetch_assoc($query))
{
$return_array[$row['userid']]=$row['userid'];
}

}



return $return_array;
}


function getAllClients(){

$query=mysql_query("select * from tbl_client order by userid asc");
$return_array=array();
if(mysql_num_rows($query)>0)
{
//$return_array['']
while($row=mysql_fetch_assoc($query))
{
$return_array[$row['id']]=$row;
}

}




return $return_array;
}

function getAuditTrail(){
$query=mysql_query("select * from tbl_audit_trail order by sysdate desc");
$return_array=array();
if(mysql_num_rows($query)>0)
{
//$return_array['']
while($row=mysql_fetch_assoc($query))
{
$return_array[$row['id']]=$row;
}

}




return $return_array;
}

function getUserLogintrack($post){
$subQuery='';
if($post['userid'])
$subQuery.=' AND username ="'.$post['userid'].'"';
if($post['periods']==1)
$subQuery.=' AND sysdate >= DATE_SUB(CURDATE(), INTERVAL 1 DAY)';
if($post['periods']==2)
$subQuery.=' AND  sysdate >= DATE_SUB(CURDATE(), INTERVAL 3 DAY)';
if($post['periods']==3)
$subQuery.=' AND  sysdate >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)';
if($post['periods']==4)
$subQuery.=' AND  sysdate >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)';
if($post['periods']==5)
$subQuery.=' AND  sysdate >= DATE_SUB(CURDATE(), INTERVAL 365 DAY)';
//print_r($post);
if($post['from_date'] && $post['to_date'])
{
	 $date1=date("Y-m-d", strtotime($post['from_date']));
		$date2=date("Y-m-d", strtotime($post['to_date']));
	$subQuery.=' AND  sysdate between "'. $date1.'" and  "'. $date2.'"';
}


//echo "select * from tbl_user_log where 1=1  ".$subQuery;


$query=mysql_query("select * from tbl_user_log where 1=1  ".$subQuery);
$return_array=array();
if(mysql_num_rows($query)>0)
{
//$return_array['']
while($row=mysql_fetch_assoc($query))
{
$return_array[]=$row;
}

}

return $return_array;
}


function getSingleUser($id){
$query=mysql_query("select * from tbl_client where id='".$id."'");
$return_array=array();
if(mysql_num_rows($query)>0)
{
//$return_array['']
while($row=mysql_fetch_assoc($query))
{
$return_array=$row;
}

}

return $return_array;
}

function getSingleUserbyName($username){
$query=mysql_query("select * from tbl_client where userid='".$username."'");
$return_array=array();
if(mysql_num_rows($query)>0)
{
//$return_array['']
while($row=mysql_fetch_assoc($query))
{
$return_array=$row;
}

}


return $return_array;
}

function getActiveUser($username)
{
$query=mysql_query("select * from tbl_user_login where username='".$username."' and loginstatus ='1'");
//$return_array=array();
if(mysql_num_rows($query)>0)
{
	return false;
}else{
return true;
}

}


function getLastLogin($username)
{
$query=mysql_query("select * from tbl_user_login where username='".$username."' and loginstatus ='1'");
//$return_array=array();
if(mysql_num_rows($query)>0)
{
	return true;
}else{
return false;
}

}


function logout($username){
mysql_query("update tbl_user_login set loginstatus='0' where  username='".$username."'  ");
}

function array_to_csv_download($array, $filename = "export.csv", $delimiter=";") {
    // open raw memory as file so no temp files needed, you might run out of memory though
    $f = fopen('php://memory', 'w'); 
    // loop over the input array
    foreach ($array as $line) { 
        // generate csv lines from the inner arrays
        fputcsv($f, $line, $delimiter); 
    }
    // rewrind the "file" with the csv lines
    fseek($f, 0);
    // tell the browser it's going to be a csv file
    header('Content-Type: application/csv');
    // tell the browser we want to save it instead of displaying it
    header('Content-Disposition: attachement; filename="'.$filename.'";');
    // make php send the generated csv lines to the browser
    fpassthru($f);
}
function array_to_txt_download($array, $filename = "export.txt", $delimiter=";") {
    // open raw memory as file so no temp files needed, you might run out of memory though
    $f = fopen('php://memory', 'w'); 
    // loop over the input array
    foreach ($array as $line) { 
        // generate csv lines from the inner arrays
        fputcsv($f, $line, $delimiter); 
    }
    // rewrind the "file" with the csv lines
    fseek($f, 0);
    // tell the browser it's going to be a csv file
    header('Content-Type: application/csv');
    // tell the browser we want to save it instead of displaying it
    header('Content-Disposition: attachement; filename="'.$filename.'";');
    // make php send the generated csv lines to the browser
    fpassthru($f);
}


?>