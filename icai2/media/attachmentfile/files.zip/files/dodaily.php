<?php
require 'include/core.php';
$query=mysql_query("INSERT INTO tbl_user_entitlementreport(	status,name,userid,van,noofentitelments,companyname,activationdate,deactivationdate,typeofnetwork,address,password)
  SELECT status,name,userid,van,noofentitelments,companyname,activationdate,deactivationdate,typeofnetwork,address,password FROM tbl_client");

?>