<?php
 /**
 * Example Application

 * @package Example-application
 */





require 'libs/Smarty.class.php';
require 'include/core.php';

$smarty = new Smarty;

if($_SESSION['username'])
{	header('Location: welcome.php');
save_audit_trial();
}

if(!empty($_POST))
{
	
	$username=mysql_real_escape_string($_POST['user_name']);
	$password=mysql_real_escape_string($_POST['user_password']);
	$query=mysql_query("select * from tbl_login where username='".$username."' and password='".$password."'");
	if(mysql_num_rows($query)>0)
	{
		$_SESSION['username']=$username;
		
	save_audit_trial("Login",$_POST['user_name']);	
	header('Location: welcome.php');
	exit;
	}else
	$smarty->assign("error","Error In User name and Password , Please Try Again ! ");
	
	
	
	
//echo "<pre>";	
//print_r($_POST);
//exit;
}


save_audit_trial("Login");
//$smarty->force_compile = true;
$smarty->debugging = false;
$smarty->caching = false;
$smarty->cache_lifetime = 120;

$array =setHead();
$smarty->assign("metas",$array);

$smarty->display('home.tpl');
